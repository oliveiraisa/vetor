let estoqueProdutos = ["camiseta", "calça", "sapato"];
estoqueProdutos.push("meia");
estoqueProdutos.shift();
estoqueProdutos[1] = "bermuda";
console.log(estoqueProdutos);