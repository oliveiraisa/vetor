let numeros = [5, 12, 8, 22, 3, 15, 7, 10, 14, 18];
let numeroParaVerificar = parseInt(prompt("Digite o número que você deseja verificar:"));
let indices = [];

for (let i = 0; i < numeros.length; i++) {
    if (numeros[i] === numeroParaVerificar) {
        indices.push(i);
    }
}

if (indices.length > 0) {
    console.log(`O número ${numeroParaVerificar} está presente nos índices: ${indices}`);
} else {
    console.log(`O número ${numeroParaVerificar} não foi encontrado no vetor.`);
}