let listaCompras = [];

for (let i = 1; i <= 3; i++) {
    let item = prompt(`Adicione o item ${i} à lista de compras:`);
    listaCompras.push(item);
}

if (listaCompras[listaCompras.length - 1] !== "leite") {
    listaCompras.push("leite");
}

console.log("Lista de compras:", listaCompras);