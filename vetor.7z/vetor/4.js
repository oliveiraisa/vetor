let tarefas = [];
for (let i = 1; i <= 3; i++) {
    let tarefa = prompt(`Ana, adicione a tarefa ${i} à lista:`);
    tarefas.push(tarefa);
}

tarefas.splice(1, 1); 
tarefas.push("ligar para o médico");

console.log("Lista de tarefas atualizada:", tarefas);