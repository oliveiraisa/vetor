let filmesFavoritos = ["Interstellar", "Inception", "Matrix"];

filmesFavoritos[0] = "O Senhor dos Anéis"; 

if (filmesFavoritos[filmesFavoritos.length - 1] !== "Harry Potter") {
    filmesFavoritos.push("Harry Potter");
}

console.log("Filmes favoritos atualizados:", filmesFavoritos);