let carrinho = [];
carrinho.push("camiseta", "calça", "sapato");
carrinho.shift();
carrinho[1] = "tênis";
console.log("Carrinho de compras atualizado:", carrinho);