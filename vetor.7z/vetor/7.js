let exerciciosSemana = ["corrida", "flexões", "abdominais"];

if (exerciciosSemana[exerciciosSemana.length - 1] !== "alongamento") {
    exerciciosSemana.push("alongamento");
}

console.log("Exercícios da semana atualizados:", exerciciosSemana);