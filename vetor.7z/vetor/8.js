let tarefasLimpeza = [];

for (let i = 1; i <= 4; i++) {
    let tarefa = prompt(`Ana, adicione a tarefa ${i} à lista de limpeza:`);
    tarefasLimpeza.push(tarefa);
}

tarefasLimpeza.splice(2, 1); 
tarefasLimpeza[1] = "limpar banheiro"; 

console.log("Tarefas de limpeza atualizadas:", tarefasLimpeza);