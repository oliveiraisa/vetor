let metasSemana = [];

metasSemana.push("estudar", "leitura", "trabalhar");

if (metasSemana[1] !== "exercício físico") {
    metasSemana[1] = "praticar esportes";
}

console.log("Metas semanais atualizadas:", metasSemana);